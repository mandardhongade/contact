USE [TestDb1]
GO

/****** Object:  Table [dbo].[ContactT]    Script Date: 7/25/2018 6:13:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ContactT](
	[ContactId] [bigint] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](100) NOT NULL,
	[LastName] [varchar](100) NULL,
	[EmailId] [varchar](100) NULL,
	[MobileNumber] [varchar](100) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[DateTimeStamp] [datetime] NULL CONSTRAINT [DF_Contact_DateTimeStamp]  DEFAULT (getdate()),
 CONSTRAINT [PK_Contact] PRIMARY KEY CLUSTERED 
(
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


